<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['user'])) {
    header("Location: login.php"); // Se não estiver logado, redireciona para o login
    exit();
}

// Inicialização das variáveis
$error = "";
$success = false; // Mudança aqui: inicializa como false

// Conexão com o banco de dados
require_once('../includes/db.php');

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $cnpj = trim($_POST['cnpj']);
        $nome_orgaos = trim($_POST['nome_orgaos']);
        $uasg = trim($_POST['uasg']) ?? null;
        $endereco = trim($_POST['endereco']) ?? null;
        $telefone = trim($_POST['telefone']) ?? null;
        $telefone2 = trim($_POST['telefone2']) ?? null;
        $email = trim($_POST['email']) ?? null;
        $email2 = trim($_POST['email2']) ?? null;
        $observacoes = trim($_POST['observacoes']) ?? null;

        // Verifica se CNPJ e Nome do Órgão estão preenchidos
        if (empty($cnpj) || empty($nome_orgaos)) {
            throw new Exception("Os campos CNPJ e Nome do Órgão são obrigatórios.");
        }

        // Insere no banco de dados
        $sql = "INSERT INTO clientes (cnpj, nome_orgaos, uasg, endereco, telefone, telefone2, email, email2, observacoes) 
                VALUES (:cnpj, :nome_orgaos, :uasg, :endereco, :telefone, :telefone2, :email, :email2, :observacoes)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':cnpj', $cnpj, PDO::PARAM_STR);
        $stmt->bindParam(':nome_orgaos', $nome_orgaos, PDO::PARAM_STR);
        $stmt->bindParam(':uasg', $uasg, PDO::PARAM_STR);
        $stmt->bindParam(':endereco', $endereco, PDO::PARAM_STR);
        $stmt->bindParam(':telefone', $telefone, PDO::PARAM_STR);
        $stmt->bindParam(':telefone2', $telefone2, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':email2', $email2, PDO::PARAM_STR);
        $stmt->bindParam(':observacoes', $observacoes, PDO::PARAM_STR);

        if ($stmt->execute()) {
            $success = true; // Agora, quando o cadastro for bem-sucedido, isso será verdadeiro
        } else {
            throw new Exception("Erro ao cadastrar o cliente.");
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Cliente - ComBraz</title>
    <script>
        function limitarCNPJ(event) {
            const input = event.target;
            let value = input.value.replace(/\D/g, ''); 
            if (value.length <= 14) {
                input.value = value;
            }
        }

        function consultarCNPJ() {
            const cnpj = document.getElementById("cnpj").value;
            if (cnpj.length === 14) {
                fetch(`consultar_cnpj.php?cnpj=${cnpj}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === "OK") {
                            document.getElementById("nome_orgaos").value = data.nome;
                            document.getElementById("endereco").value = data.logradouro + ", " + data.numero + " - " + data.bairro + " - " + data.municipio;
                            document.getElementById("telefone").value = data.telefone;
                            document.getElementById("email").value = data.email || '';  
                        } else {
                            alert("CNPJ não encontrado ou inválido.");
                        }
                    })
                    .catch(error => {
                        alert("Erro ao consultar o CNPJ.");
                        console.error("Erro na consulta: ", error);
                    });
            }
        }

        // Função para abrir e fechar o modal
        function openModal() {
            document.getElementById('successModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('successModal').style.display = 'none';
            window.location.href = 'cadastrar_clientes.php'; // Redireciona para a página de cadastro novamente
        }

        window.onload = function() {
            <?php if ($success) { echo "openModal();"; } ?>
        }
    </script>
    <style>
        /* Remover rolagem da página */
        html, body {
            height: 100%;
            margin: 0;
            overflow: hidden; /* Remove a rolagem da página */
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        header {
            background-color: rgb(157, 206, 173);
            padding: 10px 0;
            text-align: center;
        }

        /* Menu de navegação */
        nav {
            background-color: #2D893E;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 16px;
            margin: 0 10px;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #009d8f;
        }

        /* Ajuste responsivo da logo */
        .logo {
            max-width: 180px;  /* Ajusta a largura máxima da logo */
            height: auto;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            color: #2D893E;
            height: 70vh; /* Altura do container */
            overflow-y: auto; /* Adiciona a rolagem apenas ao container */
        }

        h2 {
            text-align: center;
            color: #2D893E;
            margin-bottom: 20px;
            font-size: 1.8em;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            margin-bottom: 15px;
        }

        .btn-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        button {
            flex: 1;
            padding: 12px;
            background-color: #00bfae;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin: 0 10px;
        }

        button:hover {
            background-color: #009d8f;
        }

        /* Modal Styles */
        #successModal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            width: 300px;
            margin-top: 200px;
            display: inline-block;
        }

        .btn-close {
            padding: 10px 20px;
            background-color: red;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-close:hover {
            background-color: darkred;
        }

        /* Estilizando o link do botão */
        .content-footer {
            display: flex;
            justify-content: center;  /* Centraliza o link */
            margin-top: 20px;
        }

        .content-footer a {
            background-color: #00bfae;
            color: white;
            padding: 12px 30px;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            text-align: center;
        }

        .content-footer a:hover {
            background-color: #009d8f;
        }

        /* Responsividade: ajusta o botão para telas menores */
        @media (max-width: 768px) {
            .content-footer a {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>

<header>
    <img src="../public_html/assets/images/licitasis.png" alt="Logo" class="logo">
</header>

<!-- Menu de navegação -->
<nav>
    <a href="sistema.php">Home</a>
    <a href="consultar_clientes.php">Clientes</a>
    <a href="consulta_produto.php">Produtos</a>
    <a href="financeiro.php">Financeiro</a>
    <a href="consulta_transportadoras.php">Transportadoras</a>
    <a href="consulta_fornecedores.php">Fornecedores</a>
    <a href="consulta_faturamento.php">Faturamento</a>
</nav>

<div class="container">
    <h2>Cadastro de Cliente</h2>

    <?php if ($error) { echo "<p class='error' style='color: red; text-align: center;'>$error</p>"; } ?>

    <form action="cadastrar_clientes.php" method="POST">
        <label for="cnpj">CNPJ:</label>
        <input type="text" id="cnpj" name="cnpj" required oninput="limitarCNPJ(event)" onblur="consultarCNPJ()">

        <label for="nome_orgaos">Nome do Órgão:</label>
        <input type="text" id="nome_orgaos" name="nome_orgaos" required>

        <label for="uasg">UASG:</label>
        <input type="text" id="uasg" name="uasg">

        <label for="endereco">Endereço:</label>
        <input type="text" id="endereco" name="endereco">

        <label for="telefone">Telefone:</label>
        <input type="tel" id="telefone" name="telefone">

        <label for="telefone2">Telefone 2:</label>
        <input type="tel" id="telefone2" name="telefone2">

        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email">

        <label for="email2">E-mail 2:</label>
        <input type="email" id="email2" name="email2">

        <label for="observacoes">Observações:</label>
        <textarea id="observacoes" name="observacoes"></textarea>

        <div class="btn-container">
            <button type="submit">Cadastrar Cliente</button>
            <button type="reset">Limpar</button>
        </div>
    </form>

    <div class="content-footer">
        <a href="consultar_clientes.php">Ir para página de Consulta de Clientes</a>
    </div>
</div>

<!-- Modal de sucesso -->
<div id="successModal">
    <div class="modal-content">
        <h3>Cliente cadastrado com sucesso!</h3>
        <button class="btn-close" onclick="closeModal()">Fechar</button>
    </div>
</div>

</body>
</html>
