<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['user'])) {
    header("Location: login.php"); // Se não estiver logado, redireciona para o login
    exit();
}

// Extrair o nome do usuário da sessão
$user = $_SESSION['user']; // Dados do usuário logado
$user_name = $user['name']; // O nome do usuário logado
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema - Licita Sis</title>

    <!-- Estilo CSS -->
    <style>
        /* Estilos gerais */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            height: 100vh;  /* Garante que o body ocupe toda a altura da tela */
            overflow-x: hidden; /* Evita rolagem horizontal */
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: #9fbda0;
            padding: 20px 0;
            text-align: center;
            position: sticky;
            top: 0; /* Fixa o cabeçalho no topo */
            z-index: 10; /* Garante que o cabeçalho fique acima de outros elementos */
        }

        header .logo img {
            max-width: 100%;
            height: auto;
            object-fit: contain;
            max-height: 150px;
            display: block;
            margin: 0 auto;
        }

        .welcome-container {
            background: linear-gradient(to right, rgb(68, 112, 50), #00bfae);
            color: white;
            text-align: center;
            padding: 30px;
            margin: 20px auto;
            width: 80%;
            font-size: 24px;
            font-weight: bold;
            animation: fadeIn 2s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .option-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 40px;
            padding: 0 20px;  /* Adiciona um pouco de espaçamento nas laterais */
            overflow-y: auto;  /* Permite a rolagem dentro da área de opções */
            flex-grow: 1;  /* Faz com que a área de opções cresça para ocupar o espaço restante */
        }

        .option-card {
            width: 30%;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: all 0.3s ease-in-out;
            opacity: 0;
            animation: fadeIn 1.5s ease-in-out forwards;
        }

        .option-card:nth-child(1) { animation-delay: 0.2s; }
        .option-card:nth-child(2) { animation-delay: 0.4s; }
        .option-card:nth-child(3) { animation-delay: 0.6s; }
        .option-card:nth-child(4) { animation-delay: 0.8s; }
        .option-card:nth-child(5) { animation-delay: 1s; }
        .option-card:nth-child(6) { animation-delay: 1.2s; }
        .option-card:nth-child(7) { animation-delay: 1.4s; }

        .option-card:hover {
            background-color: #f1f1f1;
            transform: translateY(-5px);
        }

        .option-card h3 {
            color: #006d56;
            font-size: 18px;
            margin-bottom: 20px;
        }

        .option-card a {
            background-color: #00bfae;
            padding: 10px;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            margin-top: 10px;
        }

        .option-card a:hover {
            background-color: #009d8f;
        }

        /* Estilos responsivos */
        @media (max-width: 1024px) {
            .option-card {
                width: 48%;  /* Para telas de tamanho médio, as opções ocupam 48% da largura */
            }
        }

        @media (max-width: 768px) {
            .option-card {
                width: 100%;  /* Para telas pequenas, as opções ocupam 100% da largura */
                margin-bottom: 20px;
            }
        }

        @media (max-width: 480px) {
            .option-card {
                width: 100%;  /* Para telas muito pequenas, as opções ocupam 100% da largura */
                margin-bottom: 20px;
            }
        }

        a.logout-btn {
            display: block;
            text-align: center;
            padding: 10px 20px;
            background-color: #00bfae;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            margin-top: 20px;
        }

        a.logout-btn:hover {
            background-color: #009d8f;
        }

        /* Inserir a logo no centro do container */
        .container-logo {
            position: absolute;
            top: 40%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20%;
            height: 70%;
            opacity: 0;
            animation: fadeIn 2s ease-in-out 1s forwards;
        }

        .container-logo img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        /* Footer */
        footer {
            background: linear-gradient(to right, rgb(68, 112, 50), #00bfae);
            color: white;
            text-align: center;
            padding: 15px 0;
            position: sticky;
            bottom: 0; /* Fixa o footer no final da página */
            width: 100%; /* Garantir que o footer ocupe toda a largura */
            opacity: 0;
            animation: fadeInFooter 1.5s ease-in-out forwards;
            animation-delay: 1.6s; /* Faz o footer aparecer por último */
        }

        footer p {
            margin: 0;
        }

        @keyframes fadeInFooter {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
    </style>
</head>
<body>

<div class="welcome-container">
    Bem-vindo(a) ao LICITA SIS, <?php echo $user_name; ?>!
</div>

<!-- Logo no centro da página -->
<div class="container-logo">
    <img src="../public_html/assets/images/licitasis.png" alt="Logo Central">
</div>

<!-- Seções de opções -->
<div class="option-container">
    <!-- Seção de Clientes -->
    <div class="option-card">
        <h3>Clientes</h3>
        <a href="./consultar_clientes.php" target="_blank">Consultar Clientes</a>
        <a href="./cadastrar_clientes.php" target="_blank">Cadastrar Cliente</a>
    </div>

    <!-- Seção de Produtos -->
    <div class="option-card">
        <h3>Produtos</h3>
        <a href="./consulta_produto.php" target="_blank">Consultar Produto</a>
        <a href="./cadastro_produto.php" target="_blank">Cadastrar Produto</a>
    </div>

    <!-- Seção de Fornecedores -->
    <div class="option-card">
        <h3>Fornecedores</h3>
        <a href="consulta_fornecedores.php" target="_blank">Consultar Fornecedor</a>
        <a href="cadastro_fornecedores.php" target="_blank">Cadastrar Fornecedor</a>
    </div>

    <!-- Seção de Transportadoras -->
    <div class="option-card">
        <h3>Transportadoras</h3>
        <a href="consulta_transportadoras.php" target="_blank">Consultar Transportadora</a>
        <a href="cadastro_transportadoras.php" target="_blank">Cadastrar Transportadora</a>
    </div>

    <!-- Seção de Empenho -->
    <div class="option-card">
        <h3>Empenho</h3>
        <a href="consulta_empenho.php" target="_blank">Consultar Empenho</a>
        <a href="cadastro_empenho.php" target="_blank">Cadastrar Empenho</a>
    </div>

    <!-- Seção de Faturamento -->
    <div class="option-card">
        <h3>Faturamento</h3>
        <a href="consulta_faturamento.php" target="_blank">Consultar Faturamento</a>
        <a href="cadastro_faturamento.php" target="_blank">Cadastrar Faturamento</a>
    </div>

    <!-- Seção de Financeiro -->
    <div class="option-card">
        <h3>Financeiro</h3>
        <a href="financeiro.php" target="_blank">Ir para Financeiro</a>
    </div>
</div>

<!-- Footer -->
<footer>
    <p>&copy; 2025 Licita Sis - Todos os direitos reservados</p>
</footer>

</body>
</html>
