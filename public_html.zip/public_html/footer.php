<!-- footer.php -->
<footer>
    <div class="footer-links">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="sobre.php">ComBraz</a></li>
            <li><a href="catalogo.php">Produtos</a></li>
            <li><a href="contato.php">Contato</a></li>
        </ul>
    </div>
    <div class="social-media">
        <a href="#" class="social-icon"><img src="assets/images/facebook-icon.png" alt="Facebook"></a>
        <a href="#" class="social-icon"><img src="assets/images/instagram-icon.png" alt="Instagram"></a>
        <a href="#" class="social-icon"><img src="assets/images/whatsapp-icon.png" alt="WhatsApp"></a>
    </div>
</footer>
